# secrets.py

secrets = {
    'TOKEN': "84df043582208624ed92672a280bc9862df5b00220b2645f53edcd0d58c3015d",
    'URL': "https://api.esios.ree.es/indicators/1001",
    'WEBHOOKS_KEY': 'cPC_vSVqJfUfu9SL0MwjZw',
    'JSON_FILE': 'pvpccheap-firebase-adminsdk-yel11-65a454a38e.json',
    'FIREBASE_URL': 'https://pvpccheap-default-rtdb.europe-west1.firebasedatabase.app/'
}
