# secrets.py

secrets = {
    'TOKEN': "84df043582208624ed92672a280bc9862df5b00220b2645f53edcd0d58c3015d",
    'URL': "https://api.esios.ree.es/indicators/1001",
    'WEBHOOKS_KEY': 'cPC_vSVqJfUfu9SL0MwjZw',
    'DB_NAME': 'pvpccheap',
    'DB_USER': 'pvpccheap_user',
    'DB_PASSWORD': 'underground666',
    'DB_HOST': '10.28.233.137',
}
